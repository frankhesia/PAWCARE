const express = require("express");
const router = express.Router();

const {
  getUsers,
  getUserById,
  createUser,
  loginUser
} = require("../controllers/userController");

router.get("/", getUsers);
router.post("/", createUser);
router.post("/login", loginUser);
router.get("/:id", getUserById);

module.exports = router;