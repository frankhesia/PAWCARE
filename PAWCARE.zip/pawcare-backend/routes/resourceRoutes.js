const express = require("express");
const router = express.Router();
const controller = require("../controllers/resourceController");

router.get("/", controller.getResources);
router.post("/", controller.createResource);
router.put("/:id", controller.updateResource);
router.delete("/:id", controller.deleteResource);

module.exports = router;