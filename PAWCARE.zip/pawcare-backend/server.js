const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const resourceRoutes = require("./routes/resourceRoutes");
const authRoutes = require("./routes/authRoutes"); // ✅ ADDED

const app = express();

// middleware
app.use(cors());
app.use(express.json());

// routes
app.use("/api/resources", resourceRoutes);
app.use("/api/auth", authRoutes); // ✅ ADDED

// connect DB
mongoose
  .connect(process.env.MONGODB_URI)
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.error("MongoDB error:", err));

// start server
const PORT = process.env.PORT || 5001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));