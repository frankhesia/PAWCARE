const User = require("../models/User");
const Pet = require("../models/Pet");

exports.getUsers = async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: "Failed to get users" });
  }
};

exports.getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    const pets = await Pet.find({ ownerId: user._id });

    res.json({ user, pets });
  } catch (error) {
    res.status(500).json({ error: "Failed to get user" });
  }
};

exports.createUser = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        error: "Name, email, and password are required"
      });
    }

    const existingUser = await User.findOne({ email });

    if (existingUser) {
      return res.status(400).json({
        error: "Email already exists"
      });
    }

    const user = await User.create({
      name,
      email,
      password,
      role: role || "owner"
    });

    res.status(201).json(user);
  } catch (error) {
    res.status(500).json({
      error: "Failed to create user"
    });
  }
};

exports.loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        error: "Email and password are required"
      });
    }

    const user = await User.findOne({ email, password });

    if (!user) {
      return res.status(401).json({
        error: "Invalid email or password"
      });
    }

    res.json(user);
  } catch (error) {
    res.status(500).json({
      error: "Failed to login"
    });
  }
};