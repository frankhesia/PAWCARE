const OpenAI = require("openai");

const client = new OpenAI({
  apiKey: process.env.OPENROUTER_API_KEY,
  baseURL: "https://openrouter.ai/api/v1",
});

exports.chatWithBot = async (req, res) => {
  try {
    const { message, petType } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Message is required" });
    }

    const completion = await client.chat.completions.create({
      model: "openrouter/free",
      messages: [
        {
          role: "system",
          content: "You are a helpful pet care assistant. Give safe advice and suggest vet if serious.",
        },
        {
          role: "user",
          content: `Pet type: ${petType}. Question: ${message}`,
        },
      ],
    });

    res.json({
      reply: completion.choices[0].message.content,
    });

  } catch (error) {
    console.error("🔥 ERROR:", error.response?.data || error.message);

    res.status(500).json({
      error: "AI assistant failed",
      details: error.message,
    });
  }
};